JSONTree
==========

Visualize JSON data using d3js collapsible tree!

Feature: 
  1) Place the JSON in the textarea and Click **Visualize** button!
  
  2) Drag and Zoom to view the data tree conviniently!
  
  
**JSONTree** uses collapsible tree layout of d3js to bring up the visualization.


What I did here?? 

I wrote a parser which will conver the JSON to the format the collapsible tree can consume!

[Checkout the Demo here](https://bvjebin.github.io/JSONTree/)

[Read About JSON here](http://json.org/)

var searchData=
[
  ['gsp_5fdbvendor',['gsp_dbvendor',['../gsp__base_8h.html#a5be3eb4b6f4ff089dbd3951ff1329e48',1,'gsp_base.h']]],
  ['gsp_5ftoken_5fcode',['gsp_token_code',['../gsp__base_8h.html#af8b1aa77eeacca821c1dea0606fe081f',1,'gsp_base.h']]]
];

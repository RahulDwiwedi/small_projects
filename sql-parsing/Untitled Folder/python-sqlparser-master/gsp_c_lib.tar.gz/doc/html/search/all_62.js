var searchData=
[
  ['bempty',['bEmpty',['../structgsp__fragment.html#aea68f08d2fdb92e9172a9a0e5c01c05d',1,'gsp_fragment']]],
  ['bsqlpluscmd',['bSqlplusCmd',['../structgsp__sourcetoken.html#a6127a00209401e1f9804505cbac840f2',1,'gsp_sourcetoken']]]
];

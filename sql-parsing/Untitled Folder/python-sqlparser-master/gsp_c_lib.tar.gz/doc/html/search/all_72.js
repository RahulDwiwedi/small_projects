var searchData=
[
  ['rolenamelist',['roleNameList',['../structgsp__drop_role_sql_node.html#aea002dbf47225ad82e98213f83ed7a89',1,'gsp_dropRoleSqlNode']]]
];
